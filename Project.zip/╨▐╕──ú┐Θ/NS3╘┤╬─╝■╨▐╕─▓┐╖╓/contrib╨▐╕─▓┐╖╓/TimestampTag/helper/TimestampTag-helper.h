#ifndef TIMESTAMPTAG_HELPER_H
#define TIMESTAMPTAG_HELPER_H

#include "ns3/TimestampTag.h"

namespace ns3
{

/* ... */

}

#endif /* TIMESTAMPTAG_HELPER_H */
