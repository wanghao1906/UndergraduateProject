#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/application.h"
#include "ns3/object-factory.h"

using namespace ns3;

//----------------------------------------------------------------------
//------------------------------------------------------
class idSender : public Application {
public:
  static TypeId GetTypeId (void);
  idSender();
  virtual ~idSender();
  void SetRemote(Address addr);
  void SetDataRate(DataRate rate);
  void SetTrafficType(uint16_t traffic);
  void SetInterval(Time time);
  void SetPktSize(uint32_t size);

protected:
  virtual void DoDispose (void);

private:
  virtual void StartApplication (void);
  virtual void StopApplication (void);

  void SendFirstPacket ();
  void SendSecondPacket ();
  void SendPacket ();

  uint32_t        m_pktSize;
  Address         m_destAddr;
  DataRate        m_dataRate;
  Time m_interval;
  uint32_t        m_numPkts;
  bool            m_trafficKind;

  Ptr<Socket>     m_socket;
  Ptr<Socket>     m_firstSocket;
  EventId         m_sendEvent;

  TracedCallback<Ptr<const Packet> > m_txTrace;

  uint32_t        m_count;

  // end class idSender
};




//------------------------------------------------------
class idReceiver : public Application {
public:
  static TypeId GetTypeId (void);
  idReceiver();
  virtual ~idReceiver();

protected:
  virtual void DoDispose (void);

private:
  virtual void StartApplication (void);
  virtual void StopApplication (void);

  void Receive (Ptr<Socket> socket);

  Ptr<Socket>     m_socket;

  uint32_t        m_port;

  bool            m_trafficKind;

  // end class idReceiver
};
