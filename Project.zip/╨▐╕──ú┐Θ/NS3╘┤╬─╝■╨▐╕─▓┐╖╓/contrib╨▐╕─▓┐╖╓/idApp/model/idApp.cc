#include <ostream>

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/socket-factory.h"
#include "idApp.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("idApps");

TypeId
idSender::GetTypeId(void)
{
  static TypeId tid = TypeId("ns3::idSender")
                          .SetParent<Application>()
                          .AddConstructor<idSender>()
                          .AddAttribute("PacketSize", "The size of packets transmitted.",
                                        UintegerValue(64),
                                        MakeUintegerAccessor(&idSender::m_pktSize),
                                        MakeUintegerChecker<uint32_t>(1))
                          .AddAttribute("Destination", "Target host address.",
                                        AddressValue(),
                                        MakeAddressAccessor(&idSender::m_destAddr),
                                        MakeAddressChecker())
                          .AddAttribute("NumPackets", "Total number of packets to send.",
                                        UintegerValue(0),
                                        MakeUintegerAccessor(&idSender::m_numPkts),
                                        MakeUintegerChecker<uint32_t>(0))
                          .AddAttribute("Interval", "Delay between first packet and the bulk of packets.",
                                        TimeValue(Seconds(1)),
                                        MakeTimeAccessor(&idSender::m_interval),
                                        MakeTimeChecker(Seconds(0)))
                          .AddAttribute("DataRate", "The data rate.",
                                        DataRateValue(DataRate("500kb/s")),
                                        MakeDataRateAccessor(&idSender::m_dataRate),
                                        MakeDataRateChecker())
                          .AddAttribute("TCPorUDP", "True if TCP traffic, otherwise UDP traffic.",
                                        BooleanValue(true),
                                        MakeBooleanAccessor(&idSender::m_trafficKind),
                                        MakeBooleanChecker())
                          .AddTraceSource("Tx", "A new packet is created and is sent",
                                          MakeTraceSourceAccessor(&idSender::m_txTrace),
                                          "ns3::Packet::TracedCallback");
  return tid;
}

idSender::idSender()
{
  NS_LOG_FUNCTION_NOARGS();
  m_interval = Seconds(0);
  m_socket = 0;
}

idSender::~idSender()
{
  NS_LOG_FUNCTION_NOARGS();
}

void idSender::DoDispose(void)
{
  NS_LOG_FUNCTION_NOARGS();

  m_socket = 0;
  // chain up
  Application::DoDispose();
}

void idSender::SetRemote(Address addr)
{
  m_destAddr = addr;
}

void idSender::SetDataRate(DataRate rate)
{
  m_dataRate = rate;
}

void idSender::SetTrafficType(uint16_t traffic)
{
  m_trafficKind = (traffic == 0)? true : false;
}

void idSender::SetInterval(Time time)
{
  m_interval = time;
}

void idSender::SetPktSize(uint32_t size)
{
  m_pktSize = size;
}

void idSender::StartApplication()
{
  NS_LOG_FUNCTION_NOARGS();

  if (m_socket == 0)
  {
    
    if (m_trafficKind)
    {
      Ptr<SocketFactory> socketFactory = GetNode()->GetObject<SocketFactory>(TcpSocketFactory::GetTypeId());
      m_socket = socketFactory->CreateSocket();
    }
    else
    {
      Ptr<SocketFactory> socketFactory = GetNode()->GetObject<SocketFactory>(UdpSocketFactory::GetTypeId());
      m_socket = socketFactory->CreateSocket();
    }

    m_socket->Bind();
    m_socket->Connect(m_destAddr);
    
  }

  m_count = 0;
  Simulator::Cancel(m_sendEvent);
  m_sendEvent = Simulator::ScheduleNow(&idSender::SendFirstPacket, this);

  // end idSender::StartApplication
}

void idSender::StopApplication()
{
  NS_LOG_FUNCTION_NOARGS();
  Simulator::Cancel(m_sendEvent);
  // end idSender::StopApplication
}

void idSender::SendFirstPacket()
{
  // NS_LOG_FUNCTION_NOARGS ();
  NS_LOG_INFO("Sending packet at " << Simulator::Now() << " to " << m_destAddr);

  Ptr<Packet> packet = Create<Packet>(m_pktSize);

  // Could connect the socket since the address never changes; using SendTo
  // here simply because all of the standard apps do not.
  m_socket->Send(packet);

  // Report the event to the trace.
  m_txTrace(packet);
  if (m_numPkts == 0)
  {
    m_sendEvent = Simulator::Schedule(Seconds(m_interval.GetSeconds()-m_startTime.GetSeconds()),
                                      &idSender::SendPacket, this);
  }
  else
  {
    if (++m_count < m_numPkts)
    {
      m_sendEvent = Simulator::Schedule(Seconds(m_interval.GetSeconds()-m_startTime.GetSeconds()),
                                        &idSender::SendPacket, this);
    }
  }

  // end idSender::SendPacket
}

void idSender::SendPacket()
{
  // NS_LOG_FUNCTION_NOARGS ();
  NS_LOG_INFO("Sending packet at " << Simulator::Now() << " to " << m_destAddr);

  Ptr<Packet> packet = Create<Packet>(m_pktSize);

  // Could connect the socket since the address never changes; using SendTo
  // here simply because all of the standard apps do not.
  m_socket->Send(packet);

  // Report the event to the trace.
  m_txTrace(packet);

  uint32_t bits = m_pktSize * 8;
  Time nextTime(Seconds(bits /
                        static_cast<double>(m_dataRate.GetBitRate())));
  NS_LOG_DEBUG("bits: "<<bits<<" datarate: "<<m_dataRate.GetBitRate()<<" nextTime: "<<nextTime.GetSeconds());
  if (m_numPkts == 0)
  {
    m_sendEvent = Simulator::Schedule(nextTime,
                                      &idSender::SendPacket, this);
  }
  else
  {
    if (++m_count < m_numPkts)
    {
      m_sendEvent = Simulator::Schedule(nextTime,
                                        &idSender::SendPacket, this);
    }
  }
  // end idSender::SendPacket
}

//----------------------------------------------------------------------
//-- idReceiver
//------------------------------------------------------
TypeId
idReceiver::GetTypeId(void)
{
  static TypeId tid = TypeId("ns3::idReceiver")
                          .SetParent<Application>()
                          .AddConstructor<idReceiver>()
                          .AddAttribute("Port", "Listening port.",
                                        UintegerValue(1603),
                                        MakeUintegerAccessor(&idReceiver::m_port),
                                        MakeUintegerChecker<uint32_t>())
                          .AddAttribute("TCPorUDP", "True if TCP traffic, otherwise UDP traffic.",
                                        BooleanValue(true),
                                        MakeBooleanAccessor(&idReceiver::m_trafficKind),
                                        MakeBooleanChecker());
  return tid;
}

idReceiver::idReceiver()
{
  NS_LOG_FUNCTION_NOARGS();
  m_socket = 0;
}

idReceiver::~idReceiver()
{
  NS_LOG_FUNCTION_NOARGS();
}

void idReceiver::DoDispose(void)
{
  NS_LOG_FUNCTION_NOARGS();

  m_socket = 0;
  // chain up
  Application::DoDispose();
}

void idReceiver::StartApplication()
{
  NS_LOG_FUNCTION_NOARGS();

  if (m_socket == 0)
  {
    if (m_trafficKind)
    {
      Ptr<SocketFactory> socketFactory = GetNode()->GetObject<SocketFactory>(TcpSocketFactory::GetTypeId());
      m_socket = socketFactory->CreateSocket();
    }
    else
    {
      Ptr<SocketFactory> socketFactory = GetNode()->GetObject<SocketFactory>(UdpSocketFactory::GetTypeId());
      m_socket = socketFactory->CreateSocket();
    }
    InetSocketAddress local =
        InetSocketAddress(Ipv4Address::GetAny(), m_port);
    m_socket->Bind(local);
    m_socket->Listen();
  }

  m_socket->SetRecvCallback(MakeCallback(&idReceiver::Receive, this));

  // end idReceiver::StartApplication
}

void idReceiver::StopApplication()
{
  NS_LOG_FUNCTION_NOARGS();

  if (m_socket != 0)
  {
    m_socket->SetRecvCallback(MakeNullCallback<void, Ptr<Socket>>());
  }

  // end idReceiver::StopApplication
}

void idReceiver::Receive(Ptr<Socket> socket)
{
  // NS_LOG_FUNCTION (this << socket << packet << from);

  Ptr<Packet> packet;
  Address from;
  while ((packet = socket->RecvFrom(from)))
  {
    if (InetSocketAddress::IsMatchingType(from))
    {
      NS_LOG_INFO("Received " << packet->GetSize() << " bytes from " << InetSocketAddress::ConvertFrom(from).GetIpv4());
    }
    // end receiving packets
  }

  // end idReceiver::Receive
}
