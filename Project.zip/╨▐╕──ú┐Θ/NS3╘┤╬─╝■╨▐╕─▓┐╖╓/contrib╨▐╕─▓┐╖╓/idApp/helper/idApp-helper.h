#ifndef IDAPP_HELPER_H
#define IDAPP_HELPER_H

#include "ns3/idApp.h"

namespace ns3
{

/* ... */

}

#endif /* IDAPP_HELPER_H */
