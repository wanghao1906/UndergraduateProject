/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2016 SEBASTIEN DERONNE
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Sebastien Deronne <sebastien.deronne@gmail.com>
 */
#include <ctime>
#include <sstream>
#include "ns3/command-line.h"
#include "ns3/pointer.h"
#include "ns3/config.h"
#include "ns3/uinteger.h"
#include "ns3/boolean.h"
#include "ns3/double.h"
#include "ns3/string.h"
#include "ns3/enum.h"
#include "ns3/log.h"
#include "ns3/yans-wifi-helper.h"
#include "ns3/spectrum-wifi-helper.h"
#include "ns3/ssid.h"
#include "ns3/mobility-helper.h"
#include "ns3/internet-stack-helper.h"
#include "ns3/ipv4-address-helper.h"
#include "ns3/udp-client-server-helper.h"
#include "ns3/packet-sink-helper.h"
#include "ns3/on-off-helper.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/packet-sink.h"
#include "ns3/yans-wifi-channel.h"
#include "ns3/multi-model-spectrum-channel.h"
#include "ns3/wifi-acknowledgment.h"
#include "ns3/rng-seed-manager.h"
#include "ns3/wifi-net-device.h"
#include "ns3/qos-txop.h"
#include "ns3/wifi-mac.h"
#include "ns3/stats-module.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/internet-module.h"
#include "ns3/stats-module.h"
#include "ns3/yans-wifi-helper.h"
#include "ns3/TimestampTag.h"
#include "ns3/wifi-mac-queue.h"
#include "ns3/idApp.h"
#include "ns3/traffic-control-helper.h"
#include "ns3/ns3-ai-module.h"
#include "ns3/wifi-psdu.h"

using namespace ns3;
using namespace std;


double totalRxMpduBytes = 0;
double SingleStaRx[64];
double lastTotalRx = 0;
// double SingleStaLastRx[64];
int n = 0;
double throughputBytes = 0;
double maxThroughput = 0;
static int CWnd = 0;

uint8_t buffer[6];
int nSta;

//增加计算误码率变量
double nRxMpdu = 0;
double nTxMpdu = 0;
double last_nRxMpdu = 0;
double last_nTxMpdu = 0;
//

//增加计算占空比变量
Time last_start_time{Seconds(10)};  //记录上一次TXOP的开始时间，初始化为10s，因为是从10s开始统计
Time total_duration{Seconds(0)};   //记录一个调度周期内总的信道繁忙时间
Time last_duration{Seconds(0)};    //记录上一次的duration
Time zero_time{Seconds(0)};
Time total_Txop{Seconds(0.1)};
//

//交互定义参数
static uint32_t last_CW = 16;
static uint32_t CW = 16;
int memblock_key = 2333;
//

//./waf --run 'scratch/scenario2.cc --useExtendedBlockAck=true --dlAckType=AGGR-MU-BAR' 2>scenaria2.log
//./ns3 run 'scratch/CW/scenario2_base.cc --useExtendedBlockAck=true --dlAckType=NO-OFDMA --RngRun=1'
NS_LOG_COMPONENT_DEFINE("scenario2");
	void traceVICw(std::string context,uint32_t cw, uint8_t linkID)
	{
		std::cout<<"VI Txop Cw: "<<cw<<std::endl;
	}
  	void traceBECw(std::string context,uint32_t cw, uint8_t linkID)
	{
		std::cout<<"BE Txop Cw: "<<cw<<std::endl;
	}
//////////////////////////////////////////////////////
/******************Ai - ns3*************************/
//////////////////////////////////////////////////////
struct AiRLCWEnv
{
  double duty_ratio;
  double per;
  double reward;
} Packed;

struct AiRLCWAct
{

	uint8_t a;
};
class CWRLEnv : public Ns3AIRL<AiRLCWEnv,AiRLCWAct>
{
public:
  CWRLEnv () = delete;
  CWRLEnv (uint16_t id);
  void ScheduleNextStateRead (double Per,double Duty_ratio,double ReWard);
  void doAction (uint8_t act);

};
CWRLEnv::CWRLEnv(uint16_t id) : Ns3AIRL<AiRLCWEnv, AiRLCWAct>(id)
{
  SetCond(2, 0);
}
void CWRLEnv::ScheduleNextStateRead(double Per,double Duty_ratio,double ReWard)
{
    auto env = EnvSetterCond();
    env->per = Per;
    env->duty_ratio = Duty_ratio;
    env->reward = ReWard;
    SetCompleted();
    auto act = ActionGetterCond();
    if (act->a == 0)
    {
        std::cout << "传输过来的动作a=0 \t" << " ;" << std::endl;
    }
    else if (act->a == 1)
    {
        std::cout << "传输过来的动作a=1 \t" << " ;" << std::endl;
    }
    else if (act->a == 2)
    {
        std::cout << "传输过来的动作a=2 \t" << " ;" << std::endl;
    }
    else
    {
        std::cout << "传输过来的动作出现错误!" << endl;
        exit(0);
    }
    //std::cout << "传输过来的动作a \t" << act->a << " ;" << std::endl;
    doAction(act->a);
    GetCompleted();

}
void CWRLEnv::doAction (uint8_t act)
{
    if (act == 0)
    {
        CW = last_CW;
    }
    else if (act == 1)
    {
        CW = floor(last_CW*1.5) ;
    }
    else if (act == 2)
    {
        CW = floor(last_CW/1.5) ;
    }
    else
    {
        std::cout << "Unsupported agent type!" << endl;
        exit(0);
    }
    uint32_t min_cw = 16;
    uint32_t max_cw = 1024;
    CW = min(max_cw, max(CW, min_cw));
    std::cout << "准备改变的CW值\t" << CW << " ;" << std::endl;
    if (CW)
    {
      Config::Set("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Mac/BE_Txop/MinCw", UintegerValue(CW));
      Config::Set("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Mac/BE_Txop/MaxCw", UintegerValue(CW));
    }
    else
    {
      NS_LOG_UNCOND("Default CW");
      Config::Set("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Mac/BE_Txop/MinCw", UintegerValue(16));
      Config::Set("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Mac/BE_Txop/MaxCw", UintegerValue(1024));
    }
    last_CW=CW;
}
//////////////////////////////////////////////////////
/******************App trace*************************/
//////////////////////////////////////////////////////

//////////////////////////////////////////////////////
/******************TCP trace*************************/
//////////////////////////////////////////////////////
void traceTcpCWND(std::string context, uint32_t oldValue, uint32_t newValue)    //TCP层的拥塞窗口大小
{
  if (oldValue != newValue)
  {
    //NS_LOG_UNCOND(context << "\t" <<Simulator::Now().GetSeconds() << " s   "<<"CWnd changed from "<<oldValue<<" to "<<newValue);
  }
  CWnd = newValue;
}

void traceAdvWnd(uint32_t oldValue, uint32_t newValue)                          //这个和下面那个都差不多，是接收方的接收窗口大小
{
  // std::cout<<"AdvWnd changed from "<<oldValue<<" to "<<newValue<<std::endl;
}

void traceRWnd(uint32_t oldValue, uint32_t newValue)
{
  // std::cout<<Simulator::Now().GetSeconds()<<"s   "<<"RWnd changed from "<<oldValue<<" to "<<newValue<<std::endl;
}

void traceTcpBIF(std::string context,uint32_t oldValue, uint32_t newValue)
{
  if(oldValue != newValue)
  {
    //NS_LOG_UNCOND(Simulator::Now().GetSeconds()<<"s   "<<" BytesInFlight: "<<newValue<<" availableWindow: "<<(CWnd-newValue)/1440);
  }
}

void traceSocket()                                                              //这个是我找问题的时候绑定的trace，所有socket的trace都必须在程序运行之后才能绑定，因为运行前没有创建这个对象，所以要用schedule
{
  Config::Connect("/NodeList/22/$ns3::TcpL4Protocol/SocketList/*/CongestionWindow", MakeCallback(&traceTcpCWND));
  //Config::ConnectWithoutContext("/NodeList/0/$ns3::TcpL4Protocol/SocketList/*/AdvWND", MakeCallback(&traceAdvWnd));
  //Config::ConnectWithoutContext("/NodeList/0/$ns3::TcpL4Protocol/SocketList/*/RWND", MakeCallback(&traceRWnd));
}

//////////////////////////////////////////////////////
/******************MAC trace*************************/
//////////////////////////////////////////////////////
void traceTxop(std::string context,Time start_time, Time duration,uint8_t linkID)    //统计占空比
{
   // NS_LOG_UNCOND("at time: " << Simulator::Now().GetNanoSeconds()<<"start time: " << start_time.GetNanoSeconds() <<" "<<"duration: "<<duration.GetNanoSeconds());
    if(start_time.GetNanoSeconds()!=last_start_time.GetNanoSeconds())
    {   total_Txop = total_Txop+(start_time-last_start_time);
        total_duration = total_duration + last_duration;
     //   NS_LOG_UNCOND("total_duration: " << total_duration.GetNanoSeconds() <<" "<<"last_duration: "<<last_duration.GetNanoSeconds());
        last_duration=duration;

    }
    else if(start_time == last_start_time)
    {
        if(duration.GetNanoSeconds()>=last_duration.GetNanoSeconds())
        {
            last_duration=duration;
         //   NS_LOG_UNCOND("total_duration: " << total_duration.GetNanoSeconds() <<" "<<"last_duration: "<<last_duration.GetNanoSeconds());
        }
    }
    last_start_time=start_time;

  //NS_LOG_UNCOND("at time: " << Simulator::Now().GetSeconds());
  //start_time.GetNanoSeconds
}




void traceMacRxMpdu(std::string context, Ptr<const WifiMpdu> q)
{
  // NS_LOG_UNCOND("At time " << Simulator::Now().GetSeconds() << " a " << q->GetSize() << " bytes mpdu was acked at Ap , packetSize = " << q->GetPacketSize());
  Ptr<const Packet> packet = q->GetPacket();
  const WifiMacHeader *macHdr = &q->GetHeader();
  if (macHdr->IsQosData() || macHdr->HasData())
  {
    nRxMpdu += 1;
    totalRxMpduBytes += q->GetPacketSize();

    macHdr->GetAddr1().CopyTo(buffer);
    nSta = int(buffer[5]);                              //这个是获取mac地址的最后一位，用来区分是哪一个STA
    if (nSta == 1) // reciever is AP ，这个时候不能用接收地址，要用发送地址
    {
      macHdr->GetAddr2().CopyTo(buffer);
      nSta = int(buffer[5]);
      SingleStaRx[nSta - 2] += q->GetPacketSize();      //记录单个STA的吞吐
    }
    else
    {
      SingleStaRx[nSta - 2] += q->GetPacketSize();

    }
  }
}

void ApMacTxTrace(std::string context, Ptr<const Packet> packet)
{
  //NS_LOG_UNCOND("At time " << Simulator::Now().GetSeconds() << " Ap send a " << packet->GetSize() << " bytes packet");
  //std::cout << "Ap send a: " <<  packet->GetSize() << "  bytes packet" << std::endl;


  if(packet->GetSize()>1000){
    TimestampTag timestamp;
    timestamp.SetTimestamp(Simulator::Now());
    packet->AddByteTag(timestamp);
  }
}

void traceBackOff(std::string context, uint32_t value)    //trace退避值
{
  NS_LOG_UNCOND(Simulator::Now().GetSeconds()<<" "<<context<<" backOff: "<<value);
}

void traceMacQueueDrop(Ptr<const WifiMpdu> item)        //mac队列丢包，任何原因
{
  NS_LOG_UNCOND("at time: " << Simulator::Now().GetSeconds() << " Mac Dropped a pakcet, size = " << item->GetPacketSize() << " SeqN: " << item->GetHeader().GetSequenceNumber() << " from: " << item->GetHeader().GetAddr2() << " to: " << item->GetHeader().GetAddr1() << " type: " << item->GetHeader().GetTypeString());
}

void traceMacQueueExpired(Ptr<const WifiMpdu> item)     //mac队列丢包，因为超时
{
  NS_LOG_UNCOND("at time: " << Simulator::Now().GetSeconds() << " Mac a pakcet expired, size = " << item->GetPacketSize() << " SeqN: " << item->GetHeader().GetSequenceNumber() << " from: " << item->GetHeader().GetAddr2() << " to: " << item->GetHeader().GetAddr1() << " type: " << item->GetHeader().GetTypeString());
}

void traceApMacQueueN(uint32_t oldValue, uint32_t newValue)     //mac队列当前长度
{
  //NS_LOG_UNCOND(Simulator::Now().GetSeconds()<<" AP Mac queue numbers changed from " << oldValue << " to " << newValue);
}

void traceRtsFailed(Mac48Address macaddr)
{
  NS_LOG_UNCOND("RTS failed: "<<macaddr);
}
void traceDataFailed(Mac48Address macaddr)
{
  NS_LOG_UNCOND("Data failed: "<<macaddr);
}
void traceRtsFinalFailed(Mac48Address macaddr)
{
  NS_LOG_UNCOND("RTS finally failed: "<<macaddr);
}
void traceDataFinalFailed(Mac48Address macaddr)
{
  NS_LOG_UNCOND("Data finally failed: "<<macaddr);
}
//////////////////////////////////////////////////////
/******************PHY trace*************************/
//////////////////////////////////////////////////////
void tracePhyTx(WifiConstPsduMap psdus, WifiTxVector txVector, double txPowerW)
{
    for (const auto& psdu : psdus)
    {
        for (auto& mpdu : *PeekPointer(psdu.second))
        {
            WifiMacHeader hdr = mpdu->GetHeader();
            if (hdr.IsQosData() && hdr.HasData())
            {
                nTxMpdu+=1;
            }
        }
    }
}
void tracePhyDrop(std::string context, Ptr<const Packet> packet, WifiPhyRxfailureReason reason) //物理层丢包
{
  Ptr<Packet> copy = packet->Copy();
  WifiMacHeader macheader;
  copy->PeekHeader(macheader);
  // NS_LOG_UNCOND("Time: " << Simulator::Now().GetSeconds() << context << " a packet has been dropped , size: " << copy->GetSize() << " TxAddr: " << macheader.GetAddr2() << " RxAddr: " << macheader.GetAddr1() << " type: " << macheader.GetTypeString() << " reason: " << reason);
}

void traceRate(uint64_t oldValue, uint64_t newValue)
{
  NS_LOG_UNCOND("Rate: "<<newValue);
}
//////////////////////////////////////////////////////
/****************Calculate throughput****************/
//////////////////////////////////////////////////////
void CalculateThroughput(CWRLEnv CWRL)
{
  int timestep = 10;                  //10ms
  Time now = Simulator::Now();                                     /* Return the simulator's virtual time. */
  double cur = (totalRxMpduBytes - lastTotalRx) * (double)8 /  (1e3 * timestep); /* Convert Application RX Packets to MBits. */
  std::cout << now.GetSeconds() << "s: \t" << cur << " Mbit/s" << std::endl;

  if (n > 0)
  {
    throughputBytes += (totalRxMpduBytes - lastTotalRx);
  }
  ++n;
  lastTotalRx = totalRxMpduBytes;
  if (cur > maxThroughput)
  {
    maxThroughput = cur;
  }
  ///误码率计算
  double per=0;
  double j,k;
  j=nRxMpdu-last_nRxMpdu;
  k=nTxMpdu-last_nTxMpdu;
  if(k!=0)
  {
    per=1-j/k;
    if(per<=0)
    {
      per=0;
    }
  }
  last_nRxMpdu=nRxMpdu;
  last_nTxMpdu=nTxMpdu;
  ///

  ///占空比计算
  double Duty_Ratio=0;
  if(total_Txop.GetNanoSeconds()!=0)
  {
      Duty_Ratio=1-((double)total_duration.GetNanoSeconds()/(double)total_Txop.GetNanoSeconds());
  }

  total_duration=zero_time;
  total_Txop=zero_time;
  //
  CWRL.ScheduleNextStateRead(per,Duty_Ratio,cur/650);//奖励值设置的是最简单的，当前吞吐量除以一个预估的最大吞吐量
  Simulator::Schedule(MilliSeconds(timestep), &CalculateThroughput,CWRL);
}


void setTrace()
{
  Config::Connect("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Mac/AckedMpdu", MakeCallback(&traceMacRxMpdu));
  Config::ConnectWithoutContext("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Phy/PhyTxPsduBegin", MakeCallback(&tracePhyTx));
  Config::Connect("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Mac/VI_Txop/TxopTrace", MakeCallback(&traceTxop));
  Config::Connect("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Mac/BE_Txop/TxopTrace", MakeCallback(&traceTxop));
  //Config::Connect("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Mac/VI_Txop/CwTrace", MakeCallback(&traceVICw));
  //Config::Connect("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Mac/BE_Txop/CwTrace", MakeCallback(&traceBECw));

}

void setEdcaTimer()
{
  Config::Set("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/HeConfiguration/BeMuEdcaTimer", TimeValue(MicroSeconds(2088960)));
  Config::Set("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/HeConfiguration/BkMuEdcaTimer", TimeValue(MicroSeconds(2088960)));
  Config::Set("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/HeConfiguration/ViMuEdcaTimer", TimeValue(MicroSeconds(2088960)));
  Config::Set("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/HeConfiguration/VoMuEdcaTimer", TimeValue(MicroSeconds(2088960)));
}

int main(int argc, char *argv[])
{
  //LogComponentEnable("PhyEntity", LogLevel(LOG_LEVEL_INFO | LOG_PREFIX_TIME));
  //LogComponentEnable("HePhy", LogLevel(LOG_LEVEL_FUNCTION | LOG_PREFIX_TIME));
  //LogComponentEnable("HeFrameExchangeManager", LogLevel(LOG_LEVEL_FUNCTION | LOG_PREFIX_TIME));
  //LogComponentEnable("WifiPhy", LogLevel(LOG_LEVEL_INFO | LOG_PREFIX_TIME));
  //LogComponentEnable("InterferenceHelper", LogLevel(LOG_LEVEL_INFO | LOG_PREFIX_TIME));
  //LogComponentEnable("MultiModelSpectrumChannel", LogLevel(LOG_LEVEL_LOGIC | LOG_PREFIX_TIME));
  //LogComponentEnable("SpectrumWifiPhy", LogLevel(LOG_LEVEL_INFO | LOG_PREFIX_TIME));

  //LogComponentEnable("HeFrameExchangeManager", LogLevel(LOG_LEVEL_FUNCTION | LOG_PREFIX_TIME));
  //LogComponentEnable("RrMultiUserScheduler", LogLevel(LOG_LEVEL_INFO | LOG_PREFIX_TIME));
  //LogComponentEnable("MultiUserScheduler", LogLevel(LOG_LEVEL_FUNCTION | LOG_PREFIX_TIME));
  //LogComponentEnable("FrameExchangeManager", LogLevel(LOG_LEVEL_FUNCTION | LOG_PREFIX_TIME));
  //LogComponentEnable("QosFrameExchangeManager", LogLevel(LOG_LEVEL_INFO | LOG_PREFIX_TIME));
  //LogComponentEnable("QosTxop", LogLevel(LOG_LEVEL_FUNCTION | LOG_PREFIX_TIME));

  //LogComponentEnable("Txop", LogLevel(LOG_LEVEL_FUNCTION | LOG_PREFIX_TIME));
  //LogComponentEnable("QosTxop", LogLevel(LOG_LEVEL_FUNCTION | LOG_PREFIX_TIME));
  //LogComponentEnable("ChannelAccessManager", LogLevel(LOG_LEVEL_INFO | LOG_PREFIX_TIME));
  //LogComponentEnable("FqCoDelQueueDisc",LogLevel(LOG_LEVEL_INFO|LOG_PREFIX_TIME));

  //LogComponentEnable("IdealWifiManager", LogLevel(LOG_LEVEL_INFO | LOG_PREFIX_TIME));

  double simulationTime{10};
  uint32_t payloadSize = 1440;
  bool tracing{true};
  // 802.11 ac
  bool acSgi{true};
  std::size_t acnStations{32};
  int acMcs{9};
  // 802.11 ax
  std::size_t axnStations{32};
  int axGi{800};
  bool useExtendedBlockAck{false};
  std::string dlAckSeqType{"NO-OFDMA"};
  int axMcs{11};

  CommandLine cmd(__FILE__);
  cmd.AddValue("tracing", "true if need pcap files", tracing);
  cmd.AddValue("acGuardInterval", "acGuardInterval", acSgi);
  cmd.AddValue("axGuardInterval", "guardInterval", axGi);
  cmd.AddValue("simulationTime", "Simulation time in seconds", simulationTime);
  cmd.AddValue("useExtendedBlockAck", "Enable/disable use of extended BACK", useExtendedBlockAck);
  cmd.AddValue("dlAckType", "Ack sequence type for DL OFDMA (NO-OFDMA, ACK-SU-FORMAT, MU-BAR, AGGR-MU-BAR)",
               dlAckSeqType);
  cmd.AddValue("acMcs", "if set, limit testing to a specific MCS (0-9)", acMcs);
  cmd.AddValue("axMcs", "if set, limit testing to a specific MCS (0-11)", axMcs);
  cmd.AddValue("payloadSize", "The application payload size in bytes", payloadSize);
  cmd.Parse(argc, argv);

  Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue(TcpNewReno::GetTypeId()));   //这个算法被我修改过，屏蔽了满启动和拥塞控制过程，竞争窗口会一直维持在初始值不变，除非发生了拥塞
  Config::SetDefault("ns3::TcpSocket::SegmentSize", UintegerValue(payloadSize));
  Config::SetDefault("ns3::TcpSocket::InitialCwnd", UintegerValue(250));        //初始竞争窗口
  Config::SetDefault("ns3::TcpSocket::SndBufSize", UintegerValue(2896000));
  Config::SetDefault("ns3::TcpSocket::RcvBufSize", UintegerValue(2896000));
  Config::SetDefault("ns3::TcpSocket::DelAckCount", UintegerValue(8));
  Config::SetDefault("ns3::TcpSocketBase::MinRto", TimeValue (Seconds (10.0)));  //TCP最小重传等待时间，我发现这个值小了导致部分STA的吞吐特别低

  /********ac*********/
  NodeContainer wifiApNode;
  wifiApNode.Create(1);
  NodeContainer acWifiStaNodes;
  acWifiStaNodes.Create(acnStations);
  NodeContainer axWifiStaNodes;
  axWifiStaNodes.Create(axnStations);

  NetDeviceContainer apDevice, acStaDevices;
  WifiMacHelper acMac;
  WifiHelper acWifi;

  NetDeviceContainer axStaDevices;
  WifiMacHelper axMac;
  WifiHelper axWifi, apWifi;

  acWifi.SetStandard(WIFI_STANDARD_80211ac);
  axWifi.SetStandard(WIFI_STANDARD_80211ax);
  apWifi.SetStandard(WIFI_STANDARD_80211ax);

  std::ostringstream oss1, oss2;
  oss1 << "VhtMcs" << acMcs;
  /* acWifi.SetRemoteStationManager("ns3::ConstantRateWifiManager", "DataMode", StringValue(oss1.str()),
                                 "RtsCtsThreshold", StringValue("0")); */
  acWifi.SetRemoteStationManager("ns3::IdealWifiManager",
                                 "RtsCtsThreshold", StringValue("0"));

  oss2 << "HeMcs" << axMcs;
  /* axWifi.SetRemoteStationManager("ns3::ConstantRateWifiManager", "DataMode", StringValue(oss2.str()),
                                 "RtsCtsThreshold", StringValue("7000000")); */
  axWifi.SetRemoteStationManager("ns3::IdealWifiManager",
                                 "RtsCtsThreshold", StringValue((dlAckSeqType == "NO-OFDMA")?"0":"7000000"));
  apWifi.SetRemoteStationManager("ns3::IdealWifiManager",
                                 "RtsCtsThreshold", StringValue((dlAckSeqType == "NO-OFDMA")?"0":"7000000"));

  acWifi.ConfigHtOptions("ShortGuardIntervalSupported", BooleanValue(acSgi));    //ac的保护间隔
  axWifi.ConfigHtOptions("ShortGuardIntervalSupported", BooleanValue(acSgi));
  axWifi.ConfigHeOptions("GuardInterval", TimeValue(NanoSeconds(axGi)),
                         "MpduBufferSize", UintegerValue(useExtendedBlockAck ? 256 : 64));    //ax的保护间隔和MPDU Buffer大小
  apWifi.ConfigHtOptions("ShortGuardIntervalSupported", BooleanValue(acSgi));
  apWifi.ConfigHeOptions("GuardInterval", TimeValue(NanoSeconds(axGi)),
                         "MpduBufferSize", UintegerValue(useExtendedBlockAck ? 256 : 64));    //ax的保护间隔和MPDU Buffer大小

  if (dlAckSeqType != "NO-OFDMA")
  {
    axMac.SetMultiUserScheduler("ns3::RrMultiUserScheduler",
                                "EnableUlOfdma", BooleanValue(true),
                                "EnableBsrp", BooleanValue(true),
                                "UseCentral26TonesRus", BooleanValue(false),
                                "NStations", UintegerValue(32));
  }

  if (dlAckSeqType == "ACK-SU-FORMAT")                  //下行OFDMA回复ACK的方式，下面两个都是
  {
    Config::SetDefault("ns3::WifiDefaultAckManager::DlMuAckSequenceType",
                       EnumValue(WifiAcknowledgment::DL_MU_BAR_BA_SEQUENCE));
  }
  else if (dlAckSeqType == "MU-BAR")
  {
    Config::SetDefault("ns3::WifiDefaultAckManager::DlMuAckSequenceType",
                       EnumValue(WifiAcknowledgment::DL_MU_TF_MU_BAR));
  }
  else if (dlAckSeqType == "AGGR-MU-BAR")
  {
    Config::SetDefault("ns3::WifiDefaultAckManager::DlMuAckSequenceType",
                       EnumValue(WifiAcknowledgment::DL_MU_AGGREGATE_TF));
  }
  else if (dlAckSeqType != "NO-OFDMA")                  //check语句，没什么用
  {
    NS_ABORT_MSG("Invalid DL ack sequence type (must be NO-OFDMA, ACK-SU-FORMAT, MU-BAR or AGGR-MU-BAR)");
  }

  Ssid ssid = Ssid("scenario2");
  /*
   * SingleModelSpectrumChannel cannot be used with 802.11ax because two
   * spectrum models are required: one with 78.125 kHz bands for HE PPDUs
   * and one with 312.5 kHz bands for, e.g., non-HT PPDUs (for more details,
   * see issue #408 (CLOSED))
   */
  Ptr<MultiModelSpectrumChannel> spectrumChannel = CreateObject<MultiModelSpectrumChannel>();   //为什么用multi可以看上面那段英文，是ns3给的

  Ptr<LogDistancePropagationLossModel> lossmodel = CreateObject<LogDistancePropagationLossModel>();     //对数距离传播损耗模型
  spectrumChannel->AddPropagationLossModel(lossmodel);

  SpectrumWifiPhyHelper phy;
  phy.SetPcapDataLinkType(WifiPhyHelper::DLT_IEEE802_11_RADIO);
  phy.SetChannel(spectrumChannel);
  std::string channelStr("{42, 80, BAND_5GHZ, 0}");
  phy.Set("ChannelSettings", StringValue(channelStr));
  phy.Set("FixedPhyBand", BooleanValue(true));
  phy.Set("RxNoiseFigure", DoubleValue(1));     //用来调整低噪的，ns3给的默认低噪和华为给的不一样
  phy.Set("RxGain", DoubleValue(3));
  phy.Set("TxGain", DoubleValue(3));
  // phy.Set("CcaEdThreshold", DoubleValue (-72.0));

  phy.Set("Antennas", UintegerValue(4));
  phy.Set("MaxSupportedTxSpatialStreams", UintegerValue(4));
  phy.Set("MaxSupportedRxSpatialStreams", UintegerValue(2));
  phy.Set("TxPowerStart", DoubleValue(23));
  phy.Set("TxPowerEnd", DoubleValue(23));

  axMac.SetType("ns3::ApWifiMac",
                "EnableBeaconJitter", BooleanValue(false),
                "Ssid", SsidValue(ssid),
                "VI_MaxAmpduSize", UintegerValue(122879),
                "BE_MaxAmpduSize", UintegerValue(122879));
  apDevice = apWifi.Install(phy, axMac, wifiApNode);

  phy.Set("Antennas", UintegerValue(2));
  phy.Set("MaxSupportedTxSpatialStreams", UintegerValue(2));
  phy.Set("MaxSupportedRxSpatialStreams", UintegerValue(2));
  phy.Set("TxPowerStart", DoubleValue(20));
  phy.Set("TxPowerEnd", DoubleValue(20));
  acMac.SetType("ns3::StaWifiMac",
                "Ssid", SsidValue(ssid),
                "BE_MaxAmpduSize", UintegerValue(122879));
  axMac.SetType("ns3::StaWifiMac",
                "Ssid", SsidValue(ssid),
                "BE_MaxAmpduSize", UintegerValue(122879));
  acStaDevices = acWifi.Install(phy, acMac, acWifiStaNodes);
  axStaDevices = axWifi.Install(phy, axMac, axWifiStaNodes);

  Ptr<NetDevice> dev = wifiApNode.Get(0)->GetDevice(0); //这一段是为了设置txop limit和mac队列的最大长度
  Ptr<WifiNetDevice> wifi_dev = DynamicCast<WifiNetDevice>(dev);
  PointerValue ptr;
  Ptr<QosTxop> edca;
  Ptr<WifiMacQueue> queue;
  wifi_dev->GetMac()->GetAttribute("VI_Txop", ptr);
  edca = ptr.Get<QosTxop>();
  edca->SetTxopLimit(MicroSeconds(4096));       //txop limit
  queue = edca->GetWifiMacQueue();
  queue->TraceConnectWithoutContext("Drop", MakeCallback(&traceMacQueueDrop));
  queue->TraceConnectWithoutContext("Expired", MakeCallback(&traceMacQueueExpired));
  //queue->TraceConnectWithoutContext("PacketsInQueue", MakeCallback(&traceApMacQueueN));

  for(std::size_t i=0; i<acnStations; i++)      //这里是为了让每个STA能和AP成功关联
  {
    Ptr<NetDevice> staDev = acWifiStaNodes.Get(i)->GetDevice(0);
    Ptr<WifiNetDevice> sta_wifi_dev = DynamicCast<WifiNetDevice>(staDev);
    sta_wifi_dev->GetMac()->SetAttribute("WaitBeaconTimeout",TimeValue (MilliSeconds (120+(i*10))));  //make sure every sta can associate successfully
  }

  for(std::size_t i=0; i<axnStations; i++)      //同上
  {
    Ptr<NetDevice> staDev = axWifiStaNodes.Get(i)->GetDevice(0);
    Ptr<WifiNetDevice> sta_wifi_dev = DynamicCast<WifiNetDevice>(staDev);
    sta_wifi_dev->GetMac()->SetAttribute("WaitBeaconTimeout",TimeValue (MilliSeconds (120+(i*10)+320)));  //make sure every sta can associate successfully
  }

  /* RngSeedManager::SetSeed(1);
  RngSeedManager::SetRun(1);
  int64_t streamNumber = 100;
  streamNumber += acWifi.AssignStreams(apDevice, streamNumber);
  streamNumber += acWifi.AssignStreams(acStaDevices, streamNumber); */

  // mobility.两个x、y坐标一开始都是7.5！！！
  MobilityHelper mobility;
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");    //运动模型-固定不动
  mobility.SetPositionAllocator("ns3::RandomDiscPositionAllocator",
                                "X", StringValue("15"),
                                "Y", StringValue("15"),
                                "Rho", StringValue("ns3::UniformRandomVariable[Min=0|Max=0]"));
  mobility.Install(wifiApNode);

  mobility.SetPositionAllocator("ns3::RandomDiscPositionAllocator",
                                "X", StringValue("15"),
                                "Y", StringValue("15"),
                               // "Rho", StringValue("ns3::UniformRandomVariable[Min=0.5|Max=7.5]"));
                               "Rho", StringValue("ns3::UniformRandomVariable[Min=0.5|Max=15]"));
  //////////////
  ///增加的/////
  ////////////
  // mobility.SetMobilityModel ("ns3::RandomWalk2dMobilityModel",        // 运动模型-随机运动
  //                            //"Bounds", RectangleValue (Rectangle (0, 20, 0, 20)),
  //                            "Speed", StringValue ("ns3::UniformRandomVariable[Min=2.0|Max=10.0]")
  //                           );

  //   mobility.SetMobilityModel ("ns3::RandomWalk2dMobilityModel",
  //                          "Mode", StringValue ("Time"),
  //                          "Time", StringValue ("2s"),
  //                          "Speed", StringValue ("ns3::ConstantRandomVariable[Constant=1.0]"),
  //                          "Bounds", StringValue ("0|200|0|200"));

  // RandomWalk2dMobilityModel模型的属性以及默认值

  // “Bounds”,“运动的范围”, RectangleValue (Rectangle (0.0, 100.0, 0.0, 100.0))
  // “Time”,“走多久换一次方向”,TimeValue (Seconds (1.0))
  // “Distance”,"走多远换一次方向"DoubleValue (1.0),
  // “Mode”,“Time or Distance”,EnumValue (RandomWalk2dMobilityModel::MODE_DISTANCE)
  // “Direction”,"随机方向 (radians)."StringValue (“ns3::UniformRandomVariable[Min=0.0|Max=6.283184]”)
  // “Speed”“随机速度 (m/s).”,StringValue (“ns3::UniformRandomVariable[Min=2.0|Max=4.0]”)
  // Mode 是选择根据运动时间来变方向还是根据运动距离来变方向

  mobility.Install(acWifiStaNodes);
  mobility.Install(axWifiStaNodes);


  /* Internet stack*/
  InternetStackHelper stack;
  stack.Install(wifiApNode);
  stack.Install(acWifiStaNodes);
  stack.Install(axWifiStaNodes);

  Ipv4AddressHelper address;
  address.SetBase("192.168.1.0", "255.255.255.0");
  Ipv4InterfaceContainer apNodeInterface;
  Ipv4InterfaceContainer acStaNodeInterfaces;
  Ipv4InterfaceContainer axStaNodeInterfaces;

  apNodeInterface = address.Assign(apDevice);
  acStaNodeInterfaces = address.Assign(acStaDevices);
  axStaNodeInterfaces = address.Assign(axStaDevices);

  /* TrafficControlHelper apTch;
  apTch.Uninstall(apDevice); */
  /* TrafficControlHelper staTch;
  staTch.Uninstall(acStaDevices);
  staTch.Uninstall(axStaDevices); */

  /* Setting applications */
  ApplicationContainer serverApp;

  // TCP flow
  /* uint16_t port1 = 50000;
  uint16_t port2 = 60000; */

  uint16_t port1 = 1603;
  uint16_t port2 = 1604;
  for (std::size_t i = 0; i < acnStations; i++)
  {
    Address localAddress(InetSocketAddress(acStaNodeInterfaces.GetAddress(i), port1));
    PacketSinkHelper packetSinkHelper("ns3::TcpSocketFactory", localAddress);
    serverApp = packetSinkHelper.Install(acWifiStaNodes.Get(i));
    serverApp.Start(Seconds(0.0));
    serverApp.Stop(Seconds(simulationTime + 10));
  }

  for(std::size_t i=0; i<acnStations; i++)
  {
    Ptr<Node> appSource = NodeList::GetNode(0);
    Ptr<idSender> sender = CreateObject<idSender>();
    InetSocketAddress dest(acStaNodeInterfaces.GetAddress(i),port1);
    DataRate rate("156250kb/s");
    dest.SetTos(0xb8);
    sender->SetRemote(dest);    //设置目标地址
    sender->SetDataRate(rate);  //数率
    sender->SetTrafficType(0);             //0 if tcp, 1 if udp
    sender->SetInterval(Seconds(10));   //发第一个包和整体业务之间的时间间隔
    appSource->AddApplication(sender);
    sender->SetStartTime(Seconds(1.0+double(i*0.1)));   //应用启动的时间
    sender->SetPktSize(payloadSize);    //每个数据包的大小
  }

  for (std::size_t i = 0; i < axnStations; i++)
  {
    Address localAddress(InetSocketAddress(axStaNodeInterfaces.GetAddress(i), port2));
    PacketSinkHelper packetSinkHelper("ns3::TcpSocketFactory", localAddress);
    serverApp = packetSinkHelper.Install(axWifiStaNodes.Get(i));
    serverApp.Start(Seconds(0.0));
    serverApp.Stop(Seconds(simulationTime + 10));
  }

  for(std::size_t i=0; i<axnStations; i++)      //这里面同上
  {
    Ptr<Node> appSource = NodeList::GetNode(0);
    Ptr<idSender> sender = CreateObject<idSender>();
    InetSocketAddress dest(axStaNodeInterfaces.GetAddress(i),port2);
    DataRate rate("156250kb/s");
    dest.SetTos(0xb8);
    sender->SetRemote(dest);
    sender->SetDataRate(rate);
    sender->SetTrafficType(0);             //0 if tcp, 1 if udp
    sender->SetInterval(Seconds(10));       //interval between first packet and the bulk of packets
    appSource->AddApplication(sender);
    sender->SetStartTime(Seconds(1.0+double(i*0.1)+3.2));
    sender->SetPktSize(payloadSize);
  }

  if (tracing)
  {
    phy.EnablePcap("scenario2", apDevice.Get(0));
    // phy.EnablePcapAll("scenario-2-" + std::to_string(frequency) + "-" + std::to_string(channelWidth));
  }
  CWRLEnv CWRL(memblock_key);
  Simulator::Schedule(Seconds(10), &CalculateThroughput, CWRL);
  Simulator::Schedule(Seconds(10),&setTrace);                   //10s后开始统计总吞吐和每个STA的吞吐
  Simulator::Schedule(Seconds(10),&setEdcaTimer);               //10s后Mu Edca Parameters才开始生效，不然会影响10s前ARP协议的完成
  Config::Connect("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Phy/PhyRxDrop", MakeCallback(&tracePhyDrop));

  //Simulator::Schedule (Seconds (1.00000001), &traceSocket);     //socket的trace要程序运行之后才能绑定，不然会报错

  Simulator::Schedule(Seconds(0), &Ipv4GlobalRoutingHelper::PopulateRoutingTables);
  Simulator::Stop(Seconds(simulationTime + 10));
  Simulator::Run();
  Simulator::Destroy();

  double totalThroughput = totalRxMpduBytes * (double) 8 / ( simulationTime * 1000000.0);
  std::cout << "Throughput" << std::endl;
  std::cout << totalThroughput << " Mbit/s" << std::endl;

  for(int i = 0; i < 64; i++)
  {
    NS_LOG_UNCOND("STA"<<i+1<<": "<<SingleStaRx[i] * (double)8 / (simulationTime * 1e6));
  }
  std::cout << "over" << std::endl;
  CWRL.SetFinish();
  return 0;
}
