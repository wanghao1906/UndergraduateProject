from ctypes import *
from py_interface import *
import os
import torch
import argparse
import numpy as np
import torch.nn as nn
import matplotlib.pyplot as plt
import random

parser = argparse.ArgumentParser()
parser.add_argument('--ckpt_dir', type=str, default='./checkpoints/DQN/')
args = parser.parse_args()

#  Python与ns3端交互所用的结构体
# 环境声明
class AiRLCWEnv(Structure):
    _pack_ = 1
    _fields_ = [
        ('duty_ratio', c_double),
        ('per', c_double),
        ('reward', c_double)
    ]
N_STATES = 2
#
class AiRLCWAct(Structure):
    _pack_ = 1
    _fields_ = [
        ('a', c_uint8)
    ]

N_ACTIONS = 3

class net(nn.Module):
    def __init__(self):
        super(net, self).__init__()
        self.layers = nn.Sequential(
            nn.Linear(N_STATES, 20),
            nn.ReLU(),
            nn.Linear(20, 20),
            nn.ReLU(),
            nn.Linear(20, N_ACTIONS),
        )

    def forward(self, x):
        return self.layers(x)

    def save_checkpoint(self, checkpoint_file):
        torch.save(self.state_dict(), checkpoint_file, _use_new_zipfile_serialization=False)

    def load_checkpoint(self, checkpoint_file):
        self.load_state_dict(torch.load(checkpoint_file))

class DQN(object):
    def __init__(self):
        self.eval_net = net()
        self.target_net = net()
        self.learn_step = 0
        self.batchsize = 32
        self.observer_shape = N_STATES  # 观察空间
        self.target_replace = 100
        self.memory_counter = 0
        self.memory_capacity = 500
        self.epsilon = 1
        self.memory = np.zeros((self.memory_capacity, self.observer_shape * 2 + 2))  # s, a, r, s'
        self.optimizer = torch.optim.Adam(
            self.eval_net.parameters(), lr=0.0001)
        self.loss_func = nn.MSELoss()
        self.checkpoint_dir = args.ckpt_dir
        self.loss = []

    def choose_action(self, x):
        x = torch.Tensor(x)
        if np.random.uniform() < (1 - self.epsilon):  # ** self.memory_counter:    # choose best
            action = self.eval_net.forward(x)
            action = torch.argmax(action, 0).item()
        else:  # explore
            action = np.random.randint(0, N_ACTIONS)
        return action

    def store_transition(self, s, a, r, s_):
        index = self.memory_counter % self.memory_capacity
        self.memory[index, :] = np.hstack((s, [a, r], s_))
        self.memory_counter += 1

    def learn(self):
        # 是否更新/替代目标网络：通过学习步长次数对替代步长求余
        self.learn_step += 1
        if self.learn_step % self.target_replace == 0:
            self.target_net.load_state_dict(self.eval_net.state_dict())

        # 基于整个记忆库进行批记忆库采样
        sample_list = np.random.choice(self.memory_capacity, self.batchsize)

        # 共选了 batch_size 条样本数据  每一行前self.n_features个为当前状态，
        # 第self.n_features个为动作 后一个为奖励 最后两个为下一个状态 将样本输入神经网络 训练神经网络  返回损失函数

        # choose a mini batch
        sample = self.memory[sample_list, :]
        s = torch.Tensor(sample[:, :self.observer_shape])
        a = torch.LongTensor(
            sample[:, self.observer_shape:self.observer_shape + 1])
        r = torch.Tensor(
            sample[:, self.observer_shape + 1:self.observer_shape + 2])
        s_ = torch.Tensor(sample[:, self.observer_shape + 2:])
        # 计算q_target,loss，反向传递
        q_eval = self.eval_net(s).gather(1, a)
        q_next = self.target_net(s_).detach()
        q_target = r + 0.8 * q_next.max(1)[0].view(self.batchsize, 1)
        loss = self.loss_func(q_eval, q_target)
        print('loss值:', loss)
        self.loss.append(loss.detach())  # 记录loss的值
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        if self.epsilon > 0.01:
            self.epsilon = self.epsilon - 0.001


class AiRLContainer:
    use_ns3ai = True

    def __init__(self, uid: int = 2333) -> None:

        self.s = []
        self.a = 0
        self.s_ = []
        self.a_ = 0
        self.r = 0
        self.agent = DQN()
        pass

    def do(self, env: AiRLCWEnv, act: AiRLCWAct, flag: bool) -> AiRLCWAct:

        self.s_ = [env.duty_ratio, env.per]  # 记录为这次状态
        act.a = self.agent.choose_action(self.s_)
        self.a_ = act.a  # this a is need change
        self.r = env.reward
        if flag:
            self.agent.store_transition(self.s, self.a, self.r, self.s_)  # 轨迹存入
        self.s = self.s_
        self.a = self.a_
        if self.agent.memory_counter > self.agent.memory_capacity:
            print('调用了learn函数')
            print('self.agent.memory_counter=', self.agent.memory_counter)
            print('self.agent.memory_capacity=', self.agent.memory_capacity)
            self.agent.learn()
        else:
            print('没有调用learn函数')
            print('self.agent.memory_counter=', self.agent.memory_counter)
            print('self.agent.memory_capacity=', self.agent.memory_capacity)
        print('发出去的改变CW的值:', act.a)
        return act

if __name__ == '__main__':

    epoch=10
    mempool_key = 1234  # memory pool key, arbitrary integer large than 1000
    mem_size = 4096  # memory pool size in bytes
    memblock_key = 2333  # memory block key, need to keep the same in the ns-3 script
    flag = False
    ns3Settings = {'useExtendedBlockAck': 'true',
                    'simulationTime': 3, 'dlAckType': 'NO-OFDMA', 'RngRun': 0}  # 元组
    ai = AiRLContainer(memblock_key)
    exp = Experiment(mempool_key, mem_size, 'scratch/CW/scenario2_base', '../../')  # Set up the ns-3 environment 场景2下
    try:
        for i in range(epoch):  # 类似于训练的epoch
            exp.reset()  # Reset the environment
            rl = Ns3AIRL(memblock_key, AiRLCWEnv, AiRLCWAct)  # Link the shared memory block with ns-3 script
            pro = exp.run(setting=ns3Settings, show_output=True)  # Set and run the ns-3 script (sim.cc)
            ns3Settings['RngRun'] = epoch + 1
            while not rl.isFinish():
                with rl as data:
                    if data == None:
                        print('python端没有数据：')
                        break
                    print('python端取出数据：')
                    print('从ns3端收到的duty_ratio值', data.env.duty_ratio)
                    print('从ns3端收到的per值', data.env.per)
                    print('从ns3端收到的reward值', data.env.reward)
                    data.act = ai.do(data.env, data.act, flag)
                    flag = True
            pro.wait()  # Wait the ns-3 to stop
    except Exception as e:
        print('Something wrong')
        print(e)
    finally:
        del exp
